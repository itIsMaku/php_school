<?php

class Auto
{

    public string $spz;
    public string $barva;

    public function __construct($spz, $barva)
    {
        $this->spz = $spz;
        $this->barva = $barva;
    }
}